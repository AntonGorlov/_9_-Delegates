//
//  AGPatient.h
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 12.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol AGPatientDelegate; //в самый вверх записываем.

@interface AGPatient : NSObject
typedef enum { //уровень мастер (Создайте список частей тела в делегате пациента (голова, живот, нога и тд) и когда пациент приходит к врачу, пусть говорит что болит.)
    AGPatientArm,
    AGPatientLeg,
    AGPatientHead,
    AGPatientHeart,
} AGPatientBody;

@property (strong,nonatomic) NSString* name;
@property (strong,nonatomic) NSString*lastName;
@property (assign,nonatomic) float temperature;
@property (strong,nonatomic) NSString* orz;
@property (strong,nonatomic) NSString* flu;

@property (weak,nonatomic) id <AGPatientDelegate> delegate;//соединяем нашего доктора с пациентами,чтобы док получал сообщения от больных.(У пациента будет ссылка на доктора).
@property (assign,nonatomic) AGPatientBody body;//уровень мастер.
@property (strong,nonatomic) NSString* arm;
@property (strong,nonatomic) NSString* leg;
@property (strong,nonatomic) NSString* head;
@property (strong,nonatomic) NSString* heart;
@property (assign,nonatomic) NSInteger drScore;

-(BOOL) howAreYou;
-(void) takePill;
-(void) makeShot;
-(void) makeKompress;
-(void) takeBioparoks;
-(void) weAreIll;
////уровень мастер.
-(BOOL) howIsYourBody;
-(void) fixingArm;
-(void) fixingLeg;
-(void) fixingHead;
-(void) fixingHeart;


@end

@protocol AGPatientDelegate <NSObject>
-(void) patient:(AGPatient*) patient hasQuestion:(NSString*) question;
-(void) patientFeelsBad:(AGPatient*) patient;
-(void) patientFeelsBadBody:(AGPatient*) patient;




@end
