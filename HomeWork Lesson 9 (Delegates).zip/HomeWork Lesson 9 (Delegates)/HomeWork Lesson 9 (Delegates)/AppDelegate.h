//
//  AppDelegate.h
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 12.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

