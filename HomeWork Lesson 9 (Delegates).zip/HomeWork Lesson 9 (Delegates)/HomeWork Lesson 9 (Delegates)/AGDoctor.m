//
//  AGDoctor.m
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 12.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGDoctor.h"
#import "AGPatient.h"


@implementation AGDoctor
#pragma mark ------- AGPatientDelegate--------


-(void) patientFeelsBad:(AGPatient*) patient{
    NSLog(@"Patient %@ %@ feels bad",patient.name,patient.lastName);
    if (patient.temperature >=37.f && patient.temperature <=38.8f) {    //&&-логическое "И".
        NSLog(@"Doctor's the diagnosis : %@ %@ has an ORZ",patient.name,patient.lastName);
        [patient takePill];
        [patient takeBioparoks];
        
    }else if (patient.temperature >38.8f){
        NSLog(@"Doctor's the diagnosis :%@ %@ has a FLU",patient.name,patient.lastName);
        [patient makeShot];
        
    }else {
        NSLog(@"Doctor's the diagnosis :Patient %@ %@ you okey ",patient.name,patient.lastName);
    }
}

-(void) patient:(AGPatient*) patient hasQuestion:(NSString*) question{
    NSLog(@"Patient %@ %@ has a question",patient.name,patient.lastName);
}
-(void) patientFeelsBadBody:(AGPatient*) patient{//уровень мастер
    NSLog(@"Patient %@ %@ feels bad",patient.name,patient.lastName);
    if (patient.leg) {
        NSLog(@"Doctor's fixing leg's for %@ %@   %@",patient.name,patient.lastName,patient.leg);
        [patient fixingLeg];
    }else if (patient.arm){
    NSLog(@"Doctor's fixing arm's for %@ %@   %@",patient.name,patient.lastName,patient.arm);
        [patient fixingArm];
    }else if (patient.head){
        NSLog(@"Doctor's fixing head's for %@ %@   %@",patient.name,patient.lastName,patient.head);
        [patient fixingHead];
    }else {
        NSLog(@"Doctor's fixing heart's for %@ %@   %@",patient.name,patient.lastName,patient.heart);
        [patient fixingHeart];
         NSLog(@"Patient %@ %@ doesn't snuffy(недовольный!!!) Score:%ld",patient.name,patient.lastName,patient.drScore);
        [patient drScore];
    }
}

-(void) report {
    
}




@end
