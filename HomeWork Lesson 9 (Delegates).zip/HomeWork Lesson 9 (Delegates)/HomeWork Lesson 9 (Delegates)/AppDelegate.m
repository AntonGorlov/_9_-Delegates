//
//  AppDelegate.m
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 12.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGDoctor.h"
#import "AGPatient.h"
#import "AGBadDoctor.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //Уровень Ученик:
    /*
     
     1. Создать пару пациентов и доктора по тому же принципу что и в видео. (Доктор делегат у пациентов)
     2. У пациента пусть будет температура и другие симптомы, по которым доктор может принимать решение.
     3. У пациента сделайте метод типа стало хуже и пусть когда станет хуже, то он идет к доктору
     4. Всех пациентов объедините в массив и в цикле вызовите метод "стало хуже".
     5. Доктор должен лечить каждого согласно симптомам.
    */
    AGPatient*patient1=[[AGPatient alloc]init];
    AGPatient*patient2=[[AGPatient alloc]init];
    AGPatient*patient3=[[AGPatient alloc]init];
    AGPatient*patient4=[[AGPatient alloc]init];
    
    [patient1 setName:@"John"];
    [patient2 setName:@"Mike"];
    patient3.name=@"Pavlo";
    patient4.name=@"Bruce";
    
    [patient1 setLastName:@"Travolta"];
    [patient2 setLastName:@"Taison"];
    patient3.lastName=@"Zibrov";
    patient4.lastName=@"Vane";
    
    [patient1 setTemperature:36.6f];
    [patient2 setTemperature:37.5f];
    patient3.temperature=39.2f;
    patient4.temperature=40.1f;
    
    
    [patient1 setOrz:@"John, you don't sick"];
    [patient2 setOrz:@"Maike, you have an ORZ"];
    patient3.orz=@"Pavlo, you don't have an ORZ you have another disease(Болезнь)";
    patient4.orz=@"Bruce,you don't have an ORZ you have another disease(Болезнь)";
    
    [patient1 setFlu:@"John, you don't sick"];
    [patient2 setFlu:@"Maike,a told you,you have an ORZ"];
    patient3.flu=@"Pavlo, you have  FLU";
    patient4.flu=@"Bruce,ou have  FLU";
    
    
    AGDoctor*doctor=[[AGDoctor alloc]init];
    doctor.name=@"MdHouse";
    
    patient1.delegate=doctor;//если у кого что случиться делегат отреагирует.(у кого лечиться пациент)
    patient2.delegate=doctor;
    patient3.delegate=doctor;
    patient4.delegate=doctor;
    
    NSLog(@"----------------------Dr.House-----------------------");
    NSLog(@"%@ %@ are you ok ?%@ " ,patient1.name,patient1.lastName,[patient1 howAreYou]? @"YES":@"NO");
    
   //  NSLog(@"%@ %@ , %@",patient1.name,patient1.lastName, [patient1 orz]);
   //  NSLog(@"%@ %@ , %@",patient1.name,patient1.lastName, [patient1 flu]);
    
    NSLog(@"%@ %@ are you ok ?%@" ,patient2.name,patient2.lastName,[patient2 howAreYou]? @"YES":@"NO");
   //  NSLog(@"%@ %@ , %@",patient2.name,patient2.lastName, [patient2 orz]);
   //  NSLog(@"%@ %@ , %@",patient2.name,patient2.lastName, [patient2 flu]);
    
    NSLog(@"%@ %@ are you ok ?%@", patient3.name,patient3.lastName,[patient3 howAreYou]? @"YES":@"NO");
   //  NSLog(@"%@ %@ , %@",patient3.name,patient3.lastName, [patient3 orz]);
   //  NSLog(@"%@ %@ , %@",patient3.name,patient3.lastName, [patient3 flu]);
    
    NSLog(@"%@ %@ are you ok ?%@",patient4.name,patient4.lastName,[patient4 howAreYou]? @"YES":@"NO");
  //   NSLog(@"%@ %@ , %@",patient4.name,patient4.lastName, [patient4 orz]);
   //  NSLog(@"%@ %@ , %@",patient4.name,patient4.lastName, [patient4 flu]);
    
    
    
    NSArray*ills=[NSArray arrayWithObjects:patient1,patient2,patient3,patient4, nil];
    
    for (NSInteger i=0; i<1; i++) {
        [patient1 weAreIll];
        [patient2 weAreIll];
        [patient3 weAreIll];
        [patient4 weAreIll];
        
        
        
        //Уровень студент
        
    /*
     6. Создайте другой класс доктора, не наследника от первого доктора, например друг :)
     7. этот друг должен лечить своих пациентов своими собственными методами и короче плохой он доктор
     8. пусть кто-то ходит к врачу, а кто-то к нему
     9. создайте пару разных объектов класса друг и пусть они лечат своих пациентов (чтобы понять что делегат это не класс, а объект)
    */
        
        AGPatient*patient5=[[AGPatient alloc]init];
        patient5.name=@"John";
        patient5.lastName=@"Rambo";
        patient5.temperature=36.6f;
        
        AGPatient*patient6=[[AGPatient alloc]init];
        patient6.name=@"Napaleon";
        patient6.lastName=@"Bonopard";
        patient6.temperature=37.8f;
        
        AGPatient*patient7=[[AGPatient alloc]init];
        patient7.name=@"Michael";
        patient7.lastName=@"Poplavskiy";
        patient7.temperature=40.8f;
        
        AGPatient*patient8=[[AGPatient alloc]init];
        patient8.name=@"Aleksandr";
        patient8.lastName=@"Duker";
        patient8.temperature=41.0f;
        
        
        AGBadDoctor*badDoctor=[[AGBadDoctor alloc]init];
        badDoctor.name=@"DR.Zoidberg";

        patient5.delegate=badDoctor;//если у кого что случиться делегат отреагирует.(к кому идти на лечение.)
        patient6.delegate=badDoctor;
        patient7.delegate=badDoctor;
        patient8.delegate=badDoctor;
        NSLog(@"----------------------Dr.Zoidberg-----------------------");
        NSLog(@"                    --Patient - John Rambo--");
           NSLog(@"%@ %@ are you ok ? %@ " ,patient5.name,patient5.lastName,[patient5 howAreYou]? @"I'm Fine":@"I'm sick");
        NSLog(@" \n                 --Patient - Napaleon Bonopard--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient6.name,patient6.lastName,[patient6 howAreYou]? @"I'm Fine":@"I'm sick");
        NSLog(@" \n                 --Patient - Michael Poplavskiy--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient7.name,patient7.lastName,[patient7 howAreYou]? @"I'm Fine":@"I'm sick");
        NSLog(@" \n                 --Patient - Aleksandr Duker--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient8.name,patient8.lastName,[patient8 howAreYou]? @"I'm Fine":@"I'm sick");
        
        
        /*Мастер:
         
         10. Создайте список частей тела в делегате пациента (голова, живот, нога и тд) и когда пациент приходит к врачу, пусть говорит что болит.
         11. Доктор должен принимать во внимание что болит
         12. Создайте у доктора метод "рапорт". Пусть в конце дня, когда все уже нажаловались достаточно, доктор составит рапорт (выдаст имена) тех у кого болит голова, потом тех у кого болел живот и тд

         */
        AGPatient*patient9=[[AGPatient alloc]init];
        patient9.name=@"Sub";
        patient9.lastName=@"Zero";
        patient9.body=AGPatientArm;
        patient9.arm=@"a left arm!";
     
        
        AGPatient*patient10=[[AGPatient alloc]init];
        patient10.name=@"Ivan";
        patient10.lastName=@"Kratov";
        [patient10 setBody:AGPatientLeg];
        patient10.leg=@"a left leg!";
        
        AGPatient*patient11=[[AGPatient alloc]init];
        patient11.name=@"Ilia";
        patient11.lastName=@"Oblomov";
       [patient11 setBody:AGPatientHead];
        patient11.head=@"a charming head!";
        
        AGPatient*patient12=[[AGPatient alloc]init];
        patient12.name=@"Iosif";
        patient12.lastName=@"Stalin";
        [patient12 setBody:AGPatientHeart];
        patient12.heart=@"a broken heart!";
        patient12.drScore=2;
        
        AGPatient*patient13=[[AGPatient alloc]init];
        patient13.name=@"Viktor";
        patient13.lastName=@"Radionov";
        [patient13 setBody:AGPatientArm];
        patient13.arm=@"a left arm!";
        patient13.drScore=5;
    
        
        AGPatient*patient14=[[AGPatient alloc]init];
        patient14.name=@"Duke";
        patient14.lastName=@"Nuken";
        [patient14 setBody:AGPatientHeart];
        patient14.heart=@"a broken heart!";
        patient14.drScore=3;
        
        
   
        
        patient9.delegate=doctor;
        patient10.delegate=doctor;
        patient11.delegate=doctor;
        patient12.delegate=doctor;
        patient13.delegate=doctor;
        patient14.delegate=doctor;
        
         NSLog(@"----------------------Dr.House-----------------------");
         NSLog(@"                  --Patient -Sub Zero--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient9.name,patient9.lastName,[patient9 howIsYourBody]? @"I'm Fine":@"I'm sick");
        NSLog(@"                   --Patient -Ivan Kratov--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient10.name,patient10.lastName,[patient10 howIsYourBody]? @"I'm Fine":@"I'm sick");
        NSLog(@"                   --Patient -Ilia Oblomov--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient11.name,patient11.lastName,[patient11 howIsYourBody]? @"I'm Fine":@"I'm sick");
        NSLog(@"                   --Patient -Iosif Stalin--");
        NSLog(@"%@ %@ are you ok ?%@  " ,patient12.name,patient12.lastName,[patient12 howIsYourBody]? @"I'm Fine":@"I'm sick");
        NSLog(@"                   --Patient -Viktor Radionov--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient13.name,patient13.lastName,[patient13 howIsYourBody]? @"I'm Fine":@"I'm sick");
        NSLog(@"                   --Patient -Duke Nuken--");
        NSLog(@"%@ %@ are you ok ?%@ " ,patient14.name,patient14.lastName,[patient14 howIsYourBody]? @"I'm Fine":@"I'm sick");

        
       
       
 //      NSDictionary//http://vk.com/topic-58860049_29055584?offset=340&z=photo-58860049_356784996%2Fpost-58860049_10407
        //12. Создайте у доктора метод "рапорт". Пусть в конце дня, когда все уже нажаловались достаточно, доктор составит рапорт (выдаст имена) тех у кого болит голова, потом тех у кого болел живот и тд.
        
        //ну про словари ты уже знаешь. Просто при обращении пациента к доктору у доктора добавляй пациента в словарь под нужным симптомом-ключом. Если один и тот же симптом может быть у нескольких людей одновременно, то вместо объекта-пациента можно писать массив пациентов с этим симптомом.
        NSDictionary*dictionaryReport=[[NSDictionary alloc]initWithObjectsAndKeys:
                                       @"An arm",patient9.lastName,
                                       @"A leg",patient10.lastName,
                                       @"A head",patient11.lastName,
                                       @"A heart",patient12.lastName,
                                       @"An arm",patient13.lastName,
                                       @"A heart",patient14.lastName,
                                       nil];
        
        
        NSLog(@"%@, \n count patients=%ld", dictionaryReport, [dictionaryReport count]);
        
        NSArray*arrayArm=[[NSArray alloc]init];
        arrayArm=[dictionaryReport allKeysForObject:@"An arm"];
        
        NSArray*arrayLeg=[[NSArray alloc]init];
        arrayLeg=[dictionaryReport allKeysForObject:@"A leg"];
        
        NSArray*arrayHead=[[NSArray alloc]init];
        arrayHead=[dictionaryReport allKeysForObject:@"A head"];
        
        NSArray*arrayHeart=[[NSArray alloc]init];
        arrayHeart=[dictionaryReport allKeysForObject:@"A heart"];
        
        NSLog(@"Arm hurts in these patient %@", arrayArm);
        NSLog(@"Leg hurts in these patient %@", arrayLeg);
        NSLog(@"Head hurts in these patient %@", arrayHead);
        NSLog(@"Heart hurts in these patient %@", arrayHeart);
  /*
        Супермен
        
        13. Создайте в классе пациента проперти - оценка доктору.
        14. Когда доктор вам назначает лечение некоторые пациенты должны стать недовольны.
        15. В конце дня после того как все лечение будет сделано и доктор напишет рапорт, надо пройтись по пациентам и всем недовольным поменять доктора.
        16. Начать новый день и убедиться что Недовольные пациенты таки поменяли доктора.
   //16-й пункт не делал,так как оценку выставляли больные(пациент 12,13,14) только  doctorУ.
   
  */
        
        //15.
        
        NSArray*patientSnuffy=[NSArray arrayWithObjects:patient9,
                                patient10,
                                patient11,
                                patient12,
                                patient13,
                                patient14, nil];
        
        for (AGPatient* allScore in patientSnuffy){
        //цикл,где пациенты ставят оценки врачам,если оценка низкая,то меняют врача.
           
        }
        if (patient12.delegate==doctor){//если лечаший врач был doctor(делегат).
            if (patient12.drScore <=3) {
             NSLog(@"Patient %@ %@ - reting of %@ - %ld",patient12.name,patient12.lastName,doctor.name,patient12.drScore);
                [patient12 setDelegate:badDoctor];//меняем делегата,если оценка <=3.
            }else {
            NSLog(@"Patient %@ %@ - reting of %@ - %ld",patient12.name,patient12.lastName,doctor.name,patient12.drScore);
            }
           
            
        
        }
        if (patient14.delegate==doctor){//если лечаший врач был doctor(делегат).
            if (patient14.drScore <=3) {
                NSLog(@"Patient %@ %@ - reting of %@ - %ld",patient14.name,patient14.lastName,doctor.name,patient14.drScore);
                [patient14 setDelegate:badDoctor];//меняем делегата,если оценка <=3.
            }else {
                NSLog(@"Patient %@ %@ - reting of %@ - %ld",patient14.name,patient14.lastName,doctor.name,patient14.drScore);
            }
          
        }
        if (patient13.delegate==doctor){//если лечаший врач был doctor(делегат).
            if (patient13.drScore <=3) {
                NSLog(@"Patient %@ %@ - reting of %@ - %ld",patient13.name,patient13.lastName,doctor.name,patient13.drScore);
                [patient13 setDelegate:badDoctor];//меняем делегата,если оценка <=3.
            }else {
                NSLog(@"Patient %@ %@ - reting of %@ - %ld",patient13.name,patient13.lastName,doctor.name,patient13.drScore);
            }
            
        }

        
        
        
        
        
        
    }
    
   
   
    
    
    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
