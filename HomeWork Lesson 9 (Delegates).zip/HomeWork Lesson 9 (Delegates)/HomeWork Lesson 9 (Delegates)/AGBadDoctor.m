//
//  AGBadDoctor.m
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 13.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGBadDoctor.h"
#import "AGPatient.h"
@implementation AGBadDoctor //этот врач не лечит людей с методом -(void) patientFeelsBadBody(компилятор вдает предупреждение).

-(void) patient:(AGPatient*) patient hasQuestion:(NSString*) question {
    NSLog(@"Patient %@ %@ has a question %@",patient.name,patient.lastName,question);
}
-(void) patientFeelsBad:(AGPatient*) patient{
    NSLog(@"Patient %@ %@ feels bad!",patient.name,patient.lastName);
    if (patient.temperature >=36.6f && patient.temperature <=38.8f) {
        NSLog(@"%@ %@ has the temperature -- %.1f",patient.name,patient.lastName,patient.temperature);
        NSLog(@"Patient %@ %@  are ok!",patient.name,patient.lastName);
    }else if (patient.temperature >=38.9f && patient.temperature <=40.2f){
        NSLog(@"%@ %@ has the temperature -- %.1f",patient.name,patient.lastName,patient.temperature);
        NSLog(@"Patient %@ %@ has a prostuda ",patient.name,patient.lastName);
       // [patient zBs];
    }else if (patient.temperature >=40.3f){
        NSLog(@"%@ %@ has the temperature -- %.1f",patient.name,patient.lastName,patient.temperature);
        NSLog(@"Patient %@ %@ has a ORZ",patient.name,patient.lastName);
        [patient takePill];
        [patient makeKompress];
        
    }
}
-(void) patient:(AGPatient*) patient iDontTakenothing:(NSString*) nothing{
    NSLog(@"%@ %@ doesn't take nothing",patient.name,patient.lastName);
}
-(void) patient:(AGPatient*) patient comeBackNextWeek:(AGPatient*) comeBack{
    NSLog(@"%@ %@ come back next week!",patient.name,patient.lastName);
}




@end
