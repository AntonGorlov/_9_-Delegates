//
//  AGPatient.m
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 12.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPatient.h"

@implementation AGPatient

-(BOOL) howAreYou {
    BOOL imOk=NO;//arc4random()%2;
    if (!imOk) {
        [self.delegate patientFeelsBad:self];//если плохо,то даем ссылку на себя.
    }
    return imOk;

}

-(void) takePill{
    NSLog(@"%@ %@ takes a pill",self.name,self.lastName);
}
-(void) makeShot{
    NSLog(@"%@ %@ makes a shot",self.name,self.lastName);
}
-(void) makeKompress{
    NSLog(@"%@ %@ makes a kompress",self.name,self.lastName);
}
-(void) takeBioparoks{
    NSLog(@"%@ %@ makes a bioparoks",self.name,self.lastName);
}
-(void) weAreIll{
    NSLog(@"%@ %@ goes to the hospital",self.name,self.lastName);
}

-(BOOL) howIsYourBody {
    BOOL myBody=arc4random ()%2;
    if (!myBody){
        [self.delegate patientFeelsBadBody:self];
    }
    return myBody;
}

-(void) fixingArm{
    NSLog(@"%@ %@ fixing %@ ",self.name,self.lastName,self.arm);
}

-(void) fixingLeg{
    NSLog(@"%@ %@ fixing %@ ",self.name,self.lastName,self.leg);

}

-(void) fixingHead {
 NSLog(@"%@ %@ fixing %@ ",self.name,self.lastName,self.head);
}

-(void) fixingHeart{
 NSLog(@"%@ %@ fixing %@ ",self.name,self.lastName,self.heart);
}

@end
