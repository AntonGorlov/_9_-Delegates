//
//  AGDoctor.h
//  HomeWork Lesson 9 (Delegates)
//
//  Created by Anton Gorlov on 12.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGPatient.h"

@protocol AGPatientDelegate;
@interface AGDoctor : NSObject <AGPatientDelegate>
@property (strong,nonatomic) NSString* name;
-(void) report;

@end
