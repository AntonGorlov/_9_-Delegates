//
//  ViewController.h
//  Delegates (Lesson 9)
//
//  Created by Anton Gorlov on 08.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

