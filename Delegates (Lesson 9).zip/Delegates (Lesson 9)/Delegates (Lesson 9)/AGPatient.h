//
//  AGPatient.h
//  Delegates (Lesson 9)
//
//  Created by Anton Gorlov on 08.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
//Сегодня в этом занятии всех пациентов обьеденим в один родительский класс

@protocol AGPatientDelegate; //название нашего класса и делегат.
@interface AGPatient : NSObject


@property (strong, nonatomic) NSString* name;
@property (assign, nonatomic) float temperature;
//ссылка на Delegate должнабыть ВСЕГДА WEAK!!!!!!!!!!!!!!!!
@property (weak, nonatomic) id <AGPatientDelegate>  delegate;//id  это уже указатель на "NSObject"
-(BOOL) howAreYou;
-(void) takePill;
-(void) makeShot;

@end

//создадим протокол Delegate в header

@protocol AGPatientDelegate <NSObject>//этот протокол будет предназначаться тому кто будет реализовывать (выполнять) прихоти пациента, реагировать на его задачи.

@required
-(void) patientFeelsBad:(AGPatient*) patient; //если один парамер передает
-(void) patient:(AGPatient*) patient hasQuestion:(NSString*) question;

@end