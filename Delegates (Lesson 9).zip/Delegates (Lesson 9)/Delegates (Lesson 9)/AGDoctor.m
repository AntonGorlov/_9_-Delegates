//
//  AGDoctor.m
//  Delegates (Lesson 9)
//
//  Created by Anton Gorlov on 10.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGDoctor.h"
#import "AGPatient.h"

@implementation AGDoctor


#pragma mark -AGPatientDelegate

-(void) patientFeelsBad:(AGPatient*) patient {//пациент приходит и говорит -я себя плохо чувствую
    NSLog(@"Patient %@ - feels bad",patient.name);
    if (patient.temperature >=37.f && patient.temperature <=39.f){
        [patient takePill];
    }else if (patient.temperature >39.f){
        [patient makeShot];
    }else {
        NSLog(@"Take it easy %@!!",patient.name);
    }

}

-(void) patient:(AGPatient*) patient hasQuestion:(NSString*) question {
    NSLog(@"Patient %@ has a question:%@",patient.name,question);
}
@end
