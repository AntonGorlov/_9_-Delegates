//
//  AGPatient.m
//  Delegates (Lesson 9)
//
//  Created by Anton Gorlov on 08.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPatient.h"

@implementation AGPatient


#pragma mark - AGPatientDelegate

-(void) patientFeelsBad:(AGPatient*) patient {

}
-(void) patient:(AGPatient*) patient hasQuestion:(NSString*) question{

}

-(BOOL) howAreYou {
    BOOL iFeelGood=NO;//arc4random()%2; //остаток от деление 2 это 0 или 1 четное или не четное.
    if (!iFeelGood) { //обратное значение (если не хорошо себя чувствую,то идем к доктору).
        [self.delegate patientFeelsBad:self];//self.delegate - идем к доктору и даем ссылку на себя(я себя плохо чувствую).
    }
    return iFeelGood;
}
-(void) takePill{
    NSLog(@"%@ takes a pill",self.name);
}
-(void) makeShot {
NSLog(@"%@ makes a shot",self.name);
}
@end
